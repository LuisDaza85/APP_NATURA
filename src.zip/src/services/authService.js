import axios from "../api/axiosConfig";

const ROL_MAP = {
  consumidor: 3,
  productor: 2,
};

export const login = async (email, password) => {
  const response = await axios.post("../screens/auth/LoginScreen", { email, password });
  return response.data;
};

export const register = async (nombre, email, password, rol) => {
  const rol_id = ROL_MAP[rol] || 3;
  const response = await axios.post("../screens/auth/RegisterScreen", {
    nombre,
    email,
    password,
    rol_id,
    telefono: null,
  });
  return response.data;
};
