
// src/services/authService.js
import axios from "../api/axiosConfig";

export const login = async (email, password) => {
  const response = await axios.post("/auth/login", { email, password }, {
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json"
    }
  });

  return response.data; // debe contener { user, token }
};
