import React, { useState, useContext } from "react";
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert } from "react-native";
import { login } from "../../services/authService";
import { AuthContext } from "../../context/AuthContext";
import { useNavigation } from "@react-navigation/native";

const LoginScreen = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const { setUser, setToken } = useContext(AuthContext);
  const navigation = useNavigation();

  const handleLogin = async () => {
    try {
      const data = await login(email, password);
      console.log("🔍 Login response:", data);

      const user = data.user || data.usuario;
      const token = data.token;

      if (!user || !token) {
        throw new Error("Respuesta inválida del servidor");
      }

      setUser(user);
      setToken(token);

      const rol = user.rol || (user.rol_id === 2 ? "productor" : "consumidor");

      // ✅ Redirección corregida
      navigation.replace(rol === "productor" ? "TabsProductor" : "TabsConsumidor");

    } catch (error) {
      console.error("❌ Login error:", error);
      Alert.alert("Error", "Credenciales inválidas o respuesta malformada.");
    }
  };


  return (
    <View style={styles.container}>
      <Text style={styles.title}>Iniciar Sesión</Text>

      <TextInput
        placeholder="Email"
        placeholderTextColor="#aaa"
        value={email}
        onChangeText={setEmail}
        style={styles.input}
        keyboardType="email-address"
      />

      <TextInput
        placeholder="Contraseña"
        placeholderTextColor="#aaa"
        value={password}
        onChangeText={setPassword}
        style={styles.input}
        secureTextEntry
      />

      <TouchableOpacity style={styles.button} onPress={handleLogin}>
        <Text style={styles.buttonText}>INICIAR SESIÓN</Text>
      </TouchableOpacity>

      {/* Botón para ir a la pantalla de registro */}
      <TouchableOpacity onPress={() => navigation.navigate("Register")} style={styles.linkContainer}>
        <Text style={styles.linkText}>¿No tienes cuenta? <Text style={styles.linkHighlight}>Regístrate</Text></Text>
      </TouchableOpacity>

    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#0f172a",
    justifyContent: "center",
    alignItems: "center",
    paddingHorizontal: 24,
  },
  title: {
    fontSize: 26,
    color: "#38bdf8",
    marginBottom: 30,
    fontWeight: "bold",
  },
  input: {
    width: "100%",
    padding: 14,
    backgroundColor: "#1e293b",
    color: "#fff",
    marginBottom: 20,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "#38bdf8",
  },
  button: {
    backgroundColor: "#38bdf8",
    paddingVertical: 14,
    paddingHorizontal: 50,
    borderRadius: 10,
    marginTop: 10,
    width: "100%",
  },
  buttonText: {
    color: "#0f172a",
    fontWeight: "bold",
    textAlign: "center",
    fontSize: 16,
  },
});

export default LoginScreen;
