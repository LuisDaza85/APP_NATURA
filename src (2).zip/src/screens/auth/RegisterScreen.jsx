import React, { useState, useContext } from "react";
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert } from "react-native";
import { register } from "../../services/authService";
import { AuthContext } from "../../context/AuthContext";
import { useNavigation } from "@react-navigation/native";

const RegisterScreen = () => {
  const [nombre, setNombre] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [rol, setRol] = useState("consumidor");

  const { setUser, setToken } = useContext(AuthContext);
  const navigation = useNavigation();

  const handleRegister = async () => {
    try {
      const data = await register(nombre, email, password, rol);
      console.log("🔍 Registro exitoso:", data);

      const user = data.user || data.usuario;
      const token = data.token;

      if (!user || !token) {
        throw new Error("Respuesta inválida del servidor");
      }

      setUser(user);
      setToken(token);

      const finalRol = user.rol || (user.rol_id === 2 ? "productor" : "consumidor");
      navigation.replace(finalRol === "productor" ? "TabsProductor" : "TabsConsumidor");

    } catch (error) {
      console.error("❌ Error en registro:", error);
      Alert.alert("Error", "No se pudo registrar. Verifica los datos o conexión.");
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Crear Cuenta</Text>

      <TextInput
        placeholder="Nombre"
        placeholderTextColor="#aaa"
        value={nombre}
        onChangeText={setNombre}
        style={styles.input}
      />

      <TextInput
        placeholder="Email"
        placeholderTextColor="#aaa"
        value={email}
        onChangeText={setEmail}
        keyboardType="email-address"
        style={styles.input}
      />

      <TextInput
        placeholder="Contraseña"
        placeholderTextColor="#aaa"
        value={password}
        onChangeText={setPassword}
        secureTextEntry
        style={styles.input}
      />

      <Text style={styles.label}>Selecciona tu rol:</Text>
      <View style={styles.roleSelector}>
        <TouchableOpacity
          style={[styles.roleOption, rol === "consumidor" && styles.selectedRole]}
          onPress={() => setRol("consumidor")}
        >
          <Text style={styles.roleText}>Consumidor</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.roleOption, rol === "productor" && styles.selectedRole]}
          onPress={() => setRol("productor")}
        >
          <Text style={styles.roleText}>Productor</Text>
        </TouchableOpacity>
      </View>

      <TouchableOpacity style={styles.button} onPress={handleRegister}>
        <Text style={styles.buttonText}>REGISTRARSE</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#0f172a",
    justifyContent: "center",
    alignItems: "center",
    paddingHorizontal: 24,
  },
  title: {
    fontSize: 26,
    color: "#38bdf8",
    marginBottom: 30,
    fontWeight: "bold",
  },
  input: {
    width: "100%",
    padding: 14,
    backgroundColor: "#1e293b",
    color: "#fff",
    marginBottom: 20,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "#38bdf8",
  },
  label: {
    color: "#38bdf8",
    marginBottom: 10,
    fontWeight: "bold",
    fontSize: 16,
    alignSelf: "flex-start",
  },
  roleSelector: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 20,
    width: "100%",
  },
  roleOption: {
    flex: 1,
    backgroundColor: "#1e293b",
    paddingVertical: 12,
    marginHorizontal: 5,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "#38bdf8",
    alignItems: "center",
  },
  selectedRole: {
    backgroundColor: "#38bdf8",
  },
  roleText: {
    color: "#fff",
    fontWeight: "bold",
  },
  button: {
    backgroundColor: "#38bdf8",
    paddingVertical: 14,
    paddingHorizontal: 50,
    borderRadius: 10,
    marginTop: 10,
    width: "100%",
  },
  buttonText: {
    color: "#0f172a",
    fontWeight: "bold",
    textAlign: "center",
    fontSize: 16,
  },
});

export default RegisterScreen;
