import React from "react";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { View, Text } from "react-native";

const Tab = createBottomTabNavigator();

const InicioConsumidor = () => (
  <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
    <Text>Pantalla del Consumidor</Text>
  </View>
);

const TabsConsumidor = () => (
  <Tab.Navigator screenOptions={{ headerShown: false }}>
    <Tab.Screen name="Inicio" component={InicioConsumidor} />
  </Tab.Navigator>
);

export default TabsConsumidor;
