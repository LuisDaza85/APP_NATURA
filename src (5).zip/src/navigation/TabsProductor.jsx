import React from "react";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { View, Text } from "react-native";

const Tab = createBottomTabNavigator();

const InicioProductor = () => (
  <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
    <Text>Pantalla del Productor</Text>
  </View>
);

const TabsProductor = () => (
  <Tab.Navigator screenOptions={{ headerShown: false }}>
    <Tab.Screen name="Inicio" component={InicioProductor} />
  </Tab.Navigator>
);

export default TabsProductor;
